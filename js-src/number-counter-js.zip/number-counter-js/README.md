# Number Counter JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jameso2/pen/yLqvGWJ](https://codepen.io/jameso2/pen/yLqvGWJ).

